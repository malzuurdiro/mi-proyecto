from setuptools import find_packages, setup

package_name = 'pfg_fanuc_control'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Alumna PFG',
    maintainer_email='alumna@example.com',
    description='Ejemplos de control del CRX-10iA/L (FollowJointTrajectory y posición directa) para el PFG',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'send_trajectory_goal = pfg_fanuc_control.send_trajectory_goal:main',
            'send_position_goal = pfg_fanuc_control.send_position_goal:main',
        ],
    },
)
