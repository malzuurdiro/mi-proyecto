#!/usr/bin/env python3
"""
send_trajectory_goal.py

Ejemplo de control del FANUC CRX-10iA/L mediante la modalidad
FollowJointTrajectory (Scaled Joint Trajectory Controller, SJTC),
la modalidad de control principal soportada por fanuc_driver.

Envía una trayectoria de dos puntos articulares (una posición
intermedia y la posición final) al controlador scaled_joint_trajectory_controller,
que interpola y ejecuta el movimiento respetando los tiempos indicados.

Requisitos previos: fanuc_moveit_config debe estar lanzado con mock hardware
(ver Código 4 de la memoria):
    ros2 launch fanuc_moveit_config fanuc_moveit.launch.py robot_model:=crx10ia_l use_mock:=true

Ejecución:
    ros2 run pfg_fanuc_control send_trajectory_goal
"""

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from builtin_interfaces.msg import Duration
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint

# Nombres de las articulaciones del CRX-10iA/L tal y como los publica
# el URDF de fanuc_crx_description (J1..J6)
JOINT_NAMES = ['J1', 'J2', 'J3', 'J4', 'J5', 'J6']

# Dos configuraciones articulares de ejemplo, en radianes
Q_HOME = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
Q_GOAL = [0.5, -0.3, 0.4, 0.0, 0.6, 0.0]


class TrajectoryGoalClient(Node):
    def __init__(self):
        super().__init__('trajectory_goal_client')
        self._client = ActionClient(
            self,
            FollowJointTrajectory,
            '/scaled_joint_trajectory_controller/follow_joint_trajectory')

    def send_goal(self):
        goal = FollowJointTrajectory.Goal()
        goal.trajectory.joint_names = JOINT_NAMES
        goal.trajectory.points = [
            JointTrajectoryPoint(
                positions=Q_HOME,
                time_from_start=Duration(sec=0)),
            JointTrajectoryPoint(
                positions=Q_GOAL,
                time_from_start=Duration(sec=4)),
        ]

        self._client.wait_for_server()
        self.get_logger().info('Enviando trayectoria de 2 puntos al SJTC...')

        self._send_goal_future = self._client.send_goal_async(
            goal, feedback_callback=self.feedback_cb)
        self._send_goal_future.add_done_callback(self.goal_response_cb)

    def feedback_cb(self, feedback_msg):
        actual = feedback_msg.feedback.actual.positions
        self.get_logger().info(f'Posición articular actual: {[round(p, 2) for p in actual]}')

    def goal_response_cb(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('Trayectoria rechazada por el controlador')
            return
        self._result_future = goal_handle.get_result_async()
        self._result_future.add_done_callback(self.result_cb)

    def result_cb(self, future):
        result = future.result().result
        self.get_logger().info(f'Trayectoria completada, error final: {result.error_code}')
        rclpy.shutdown()


def main(args=None):
    rclpy.init(args=args)
    node = TrajectoryGoalClient()
    node.send_goal()
    rclpy.spin(node)


if __name__ == '__main__':
    main()
