#!/usr/bin/env python3
"""
send_position_goal.py

Ejemplo de control del FANUC CRX-10iA/L mediante consigna de posición
directa (forward_position_controller), sin interpolación temporal.

Requiere que el controller_manager tenga cargado y activo el
forward_position_controller (ver Capítulo 6 de la memoria para su
configuración en el archivo de controladores del paquete
fanuc_moveit_config personalizado).

Ejecución:
    ros2 run pfg_fanuc_control send_position_goal
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

# Configuración articular objetivo (radianes), en el mismo orden que
# los joints declarados en el controlador (J1..J6)
Q_GOAL = [0.2, -0.2, 0.3, 0.0, 0.4, 0.0]


class PositionGoalPublisher(Node):
    def __init__(self):
        super().__init__('position_goal_publisher')
        self._publisher = self.create_publisher(
            Float64MultiArray,
            '/forward_position_controller/commands',
            10)
        # Pequeña espera para asegurar que el publisher se ha registrado
        # correctamente antes de publicar (patrón habitual en ROS2)
        self.create_timer(1.0, self.send_once)
        self._sent = False

    def send_once(self):
        if self._sent:
            return
        msg = Float64MultiArray()
        msg.data = Q_GOAL
        self._publisher.publish(msg)
        self.get_logger().info(f'Consigna de posición enviada: {Q_GOAL}')
        self._sent = True


def main(args=None):
    rclpy.init(args=args)
    node = PositionGoalPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
