#!/usr/bin/env python3
"""
publisher_node.py

Ejemplo de concepto ROS2: NODO + TOPIC (publisher).

Publica periódicamente mensajes geometry_msgs/Twist en el topic /cmd_vel
para mover el TurtleBot3 (real o simulado en Gazebo) en una trayectoria
circular. Ilustra:
  - Cómo se crea un nodo (rclpy.node.Node)
  - Cómo se declara un publisher sobre un topic con un tipo de mensaje
  - Cómo se publica a una frecuencia fija mediante un timer

Ejecución (con Gazebo + TurtleBot3 ya lanzado, ver README):
    ros2 run pfg_tb3_examples publisher_node
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


class CirclePublisher(Node):
    def __init__(self):
        super().__init__('circle_publisher')

        # Publisher: topic '/cmd_vel', tipo Twist, cola de 10 mensajes
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)

        # Timer: llama a timer_callback cada 0.1 s (10 Hz)
        timer_period = 0.1
        self.timer = self.create_timer(timer_period, self.timer_callback)

        self.get_logger().info('Nodo circle_publisher iniciado, publicando en /cmd_vel')

    def timer_callback(self):
        msg = Twist()
        msg.linear.x = 0.15   # velocidad lineal (m/s), TB3 Burger admite hasta ~0.22
        msg.angular.z = 0.3   # velocidad angular (rad/s) -> trayectoria circular
        self.publisher_.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = CirclePublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # Detener el robot al salir, por seguridad
        stop = Twist()
        node.publisher_.publish(stop)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
