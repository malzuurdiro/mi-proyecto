#!/usr/bin/env python3
"""
rotate_action_server.py

Ejemplo de concepto ROS2: ACTION (servidor).

Implementa el servidor de la action personalizada pfg_tb3_interfaces/Rotate:
recibe un ángulo objetivo, gira el TurtleBot3 sobre sí mismo publicando en
/cmd_vel, se guía por la odometría (/odom) para saber cuánto lleva girado,
y reporta feedback periódico (ángulo restante) hasta completar el giro.

Este es el "hermano" del ejemplo de action_client_node.py, y muestra el
lado servidor del patrón que más adelante se reutilizará para ejecutar
trayectorias completas en el robot FANUC (control_msgs/FollowJointTrajectory
funciona con el mismo patrón goal + feedback + result).

Ejecución (con Gazebo + TurtleBot3 ya lanzado):
    ros2 run pfg_tb3_examples rotate_action_server
"""

import math
import rclpy
from rclpy.action import ActionServer
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from rclpy.callback_groups import ReentrantCallbackGroup
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry

from pfg_tb3_interfaces.action import Rotate


def yaw_from_quaternion(q):
    siny_cosp = 2 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def normalize_angle(angle):
    while angle > math.pi:
        angle -= 2 * math.pi
    while angle < -math.pi:
        angle += 2 * math.pi
    return angle


class RotateActionServer(Node):
    def __init__(self):
        super().__init__('rotate_action_server')

        self._callback_group = ReentrantCallbackGroup()
        self._current_yaw = None

        self._cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self._odom_sub = self.create_subscription(
            Odometry, '/odom', self._odom_callback, 10,
            callback_group=self._callback_group)

        self._action_server = ActionServer(
            self,
            Rotate,
            'rotate',
            execute_callback=self.execute_callback,
            callback_group=self._callback_group)

        self.get_logger().info('Action server "rotate" listo')

    def _odom_callback(self, msg: Odometry):
        self._current_yaw = yaw_from_quaternion(msg.pose.pose.orientation)

    def execute_callback(self, goal_handle):
        self.get_logger().info(f'Goal recibido: girar {goal_handle.request.target_angle:.2f} rad')

        rate = self.create_rate(10)  # 10 Hz
        while self._current_yaw is None:
            rate.sleep()

        start_yaw = self._current_yaw
        target = normalize_angle(goal_handle.request.target_angle)
        feedback_msg = Rotate.Feedback()

        angular_speed = 0.4 if target >= 0 else -0.4
        twist = Twist()
        twist.angular.z = angular_speed

        rotated = 0.0
        last_yaw = start_yaw

        while abs(rotated) < abs(target):
            self._cmd_vel_pub.publish(twist)

            delta = normalize_angle(self._current_yaw - last_yaw)
            rotated += delta
            last_yaw = self._current_yaw

            remaining = abs(target) - abs(rotated)
            feedback_msg.remaining_angle = remaining
            goal_handle.publish_feedback(feedback_msg)

            rate.sleep()

        # Detener el robot
        self._cmd_vel_pub.publish(Twist())

        goal_handle.succeed()
        result = Rotate.Result()
        result.total_rotated = rotated
        self.get_logger().info(f'Giro completado: {rotated:.2f} rad')
        return result


def main(args=None):
    rclpy.init(args=args)
    node = RotateActionServer()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
