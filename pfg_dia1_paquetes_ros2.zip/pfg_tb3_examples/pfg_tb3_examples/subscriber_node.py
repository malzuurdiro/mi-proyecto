#!/usr/bin/env python3
"""
subscriber_node.py

Ejemplo de concepto ROS2: NODO + TOPIC (subscriber).

Se suscribe al topic /odom (tipo nav_msgs/msg/Odometry) y muestra por
consola la posición (x, y) y orientación (yaw, calculado desde el
cuaternión) del TurtleBot3. Complementa a publisher_node.py para mostrar
el patrón publisher/subscriber completo.

Ejecución:
    ros2 run pfg_tb3_examples publisher_node    (para que el robot se mueva)
    ros2 run pfg_tb3_examples subscriber_node
"""

import math
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry


def yaw_from_quaternion(q):
    """Extrae el ángulo yaw (rotación en Z) a partir de un cuaternión."""
    siny_cosp = 2 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


class OdomSubscriber(Node):
    def __init__(self):
        super().__init__('odom_subscriber')

        self.subscription = self.create_subscription(
            Odometry,
            '/odom',
            self.odom_callback,
            10)

        self.get_logger().info('Nodo odom_subscriber iniciado, escuchando /odom')

    def odom_callback(self, msg: Odometry):
        pos = msg.pose.pose.position
        yaw = yaw_from_quaternion(msg.pose.pose.orientation)
        self.get_logger().info(
            f'Posición actual -> x: {pos.x:.2f}, y: {pos.y:.2f}, yaw: {yaw:.2f} rad'
        )


def main(args=None):
    rclpy.init(args=args)
    node = OdomSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
