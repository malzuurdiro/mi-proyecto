#!/usr/bin/env python3
"""
service_client_node.py

Ejemplo de concepto ROS2: SERVICIO (cliente).

Actúa como cliente del servicio /reset_simulation (tipo std_srvs/srv/Empty),
que Gazebo expone automáticamente al lanzar cualquier simulación, para
reiniciar la simulación de TurtleBot3 a su estado inicial. Ilustra el
patrón request/response propio de los servicios ROS2, distinto del
patrón continuo de los topics.

Ejecución (con Gazebo + TurtleBot3 ya lanzado):
    ros2 run pfg_tb3_examples service_client_node
"""

import rclpy
from rclpy.node import Node
from std_srvs.srv import Empty


class ResetSimulationClient(Node):
    def __init__(self):
        super().__init__('reset_simulation_client')
        self.client = self.create_client(Empty, '/reset_simulation')

        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Esperando a que el servicio /reset_simulation esté disponible...')

    def send_request(self):
        request = Empty.Request()
        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        return future.result()


def main(args=None):
    rclpy.init(args=args)
    node = ResetSimulationClient()
    node.send_request()
    node.get_logger().info('Simulación reiniciada a su estado inicial')
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
