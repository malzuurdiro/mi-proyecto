#!/usr/bin/env python3
"""
rotate_action_client.py

Ejemplo de concepto ROS2: ACTION (cliente).

Cliente de la action personalizada pfg_tb3_interfaces/Rotate. Envía un
objetivo de giro (en radianes) al rotate_action_server y muestra por
consola el feedback recibido (ángulo restante) hasta la finalización.

A diferencia de un servicio, una action:
  - Tiene una tarea de larga duración (puede tardar varios segundos)
  - Proporciona feedback periódico durante la ejecución
  - Puede cancelarse antes de completarse

Ejecución (con rotate_action_server ya corriendo):
    ros2 run pfg_tb3_examples rotate_action_client
"""

import math
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node

from pfg_tb3_interfaces.action import Rotate


class RotateActionClient(Node):
    def __init__(self):
        super().__init__('rotate_action_client')
        self._action_client = ActionClient(self, Rotate, 'rotate')

    def send_goal(self, target_angle: float):
        goal_msg = Rotate.Goal()
        goal_msg.target_angle = target_angle

        self._action_client.wait_for_server()

        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg,
            feedback_callback=self.feedback_callback)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal de rotación rechazado')
            return

        self.get_logger().info('Goal de rotación aceptado')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def feedback_callback(self, feedback_msg):
        remaining = feedback_msg.feedback.remaining_angle
        self.get_logger().info(f'Feedback -> ángulo restante: {remaining:.2f} rad')

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info(f'Rotación completada, total girado: {result.total_rotated:.2f} rad')
        rclpy.shutdown()


def main(args=None):
    rclpy.init(args=args)
    node = RotateActionClient()
    node.send_goal(math.pi / 2)  # objetivo: 90 grados
    rclpy.spin(node)


if __name__ == '__main__':
    main()
