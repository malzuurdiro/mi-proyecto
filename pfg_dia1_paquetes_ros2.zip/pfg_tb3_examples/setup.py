from setuptools import find_packages, setup

package_name = 'pfg_tb3_examples'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Alumna PFG',
    maintainer_email='alumna@example.com',
    description='Ejemplos ROS2 (nodo, topic, servicio, action) con TurtleBot3 para el PFG',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'publisher_node = pfg_tb3_examples.publisher_node:main',
            'subscriber_node = pfg_tb3_examples.subscriber_node:main',
            'service_client_node = pfg_tb3_examples.service_client_node:main',
            'rotate_action_server = pfg_tb3_examples.rotate_action_server:main',
            'rotate_action_client = pfg_tb3_examples.rotate_action_client:main',
        ],
    },
)
